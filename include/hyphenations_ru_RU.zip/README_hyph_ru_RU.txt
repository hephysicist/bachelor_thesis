 This file has been converted for the hyph-utf8 project from various files
 [FIXME document] whose author has been identified as Alexander I. Lebedev
 <swan at scon155.phys.msu.su> (2003-03-10).  The licence terms are unchanged.

 See http://www.hyphenation.org for details on the project.
------------------------------------------------------------------------------

 Russian hyphenation patterns, version 2003/03/10
 Copyright 1999-2003 Alexander I. Lebedev <swan@scon155.phys.msu.su>

 This program may be distributed and/or modified under the conditions
 of the LaTeX Project Public License, either version 1.2 or any later
 version.

 Patterns were generated with patgen from a 990,000-word list and then
 manually corrected.

 The program consists of the files ruhyphal.tex, cyryoal.tex and two
 document files README.ruhyphal and hyphen.rules.  The file cyryoal.tex
 can be regenerated using mkcyryo script (a part of ruhyphen package)
 and the latest release of rus-ispell dictionaries
 <ftp://scon155.phys.msu.su/pub/russian/ispell/>.
